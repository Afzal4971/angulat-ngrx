export interface Customer {
     id?: number;
     name: string;
     phone: string;
     address: string;
     membership: string;
   }